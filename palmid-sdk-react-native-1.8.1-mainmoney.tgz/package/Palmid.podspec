require "json"

package = JSON.parse(File.read(File.join(__dir__, "package.json")))

next_version = package['native']['ios']['version']

version_file = File.join(__dir__, 'ios/Frameworks/version')
if File.exist?(version_file)
  version = File.read(version_file).strip
else
  version = nil
end

if version != next_version
  puts "\e[32mDownloading PalmIDNativeSDK-#{next_version}.zip\e[0m"
  
  url = "https://rrbpalm-dist.vecrel.com/ios/PalmIDNativeSDK-#{next_version}.zip"
  `curl -L -o PalmIDNativeSDK-#{next_version}.zip #{url}`
  `unzip PalmIDNativeSDK-#{next_version}.zip`
  `mv PalmIDNativeSDK/Frameworks/* ios/Frameworks/`
  `rm -rf PalmIDNativeSDK`
  `rm PalmIDNativeSDK-#{next_version}.zip`
  `touch ios/Frameworks/version`
  `echo #{next_version} > ios/Frameworks/version`
end

Pod::Spec.new do |s|
  s.name         = "Palmid"
  s.version      = package["version"]
  s.summary      = package["description"]
  s.homepage     = package["homepage"]
  s.license      = package["license"]
  s.authors      = package["author"]

  s.platforms    = { :ios => min_ios_version_supported }
  s.source       = { :git => "https://github.com/redrockbiometrics/palmid-sdk-react-native.git", :tag => "#{s.version}" }

  s.source_files = "ios/**/*.{h,m,mm,cpp}"
  s.private_header_files = "ios/**/*.h"
  s.ios.vendored_frameworks = "ios/Frameworks/*.{xcframework,framework}"


  install_modules_dependencies(s)
end
