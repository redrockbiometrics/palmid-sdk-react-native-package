const {
  withProjectBuildGradle,
  withAppBuildGradle,
  createRunOncePlugin,
} = require('@expo/config-plugins');

/**
 * Add PalmID SDK Maven repositories to project build.gradle
 */
const withPalmIdMavenRepos = (config) => {
  return withProjectBuildGradle(config, (configMod) => {
    const buildGradle = configMod.modResults.contents;

    // Maven repositories to add
    const mavenRepos = `
        // PalmID SDK repositories
        maven {
            url = uri("https://storage.googleapis.com/download.flutter.io")
        }
        maven {
            url = uri("https://raw.githubusercontent.com/redrockbiometrics/palmid-sdk-android-repo/master")
        }`;

    // Check if already added
    if (buildGradle.includes('redrockbiometrics/palmid-sdk-android-repo')) {
      return config;
    }

    // Find allprojects { repositories { ... } } block and add maven repos
    const allProjectsPattern = /allprojects\s*\{\s*repositories\s*\{/;
    const match = buildGradle.match(allProjectsPattern);

    if (match) {
      // Add after the opening brace of repositories
      const insertIndex = match.index + match[0].length;
      configMod.modResults.contents =
        buildGradle.slice(0, insertIndex) +
        mavenRepos +
        buildGradle.slice(insertIndex);
    }

    return configMod;
  });
};

/**
 * Add ABI filters to app build.gradle (arm64-v8a only)
 * Uses splits.abi to filter all native libraries including AAR dependencies
 */
const withAbiFilters = (config) => {
  return withAppBuildGradle(config, (configMod) => {
    let buildGradle = configMod.modResults.contents;

    // Check if already added
    if (buildGradle.includes('splits {')) {
      return config;
    }

    // Add splits.abi configuration to only include arm64-v8a
    const androidBlockEnd = /(\n\s*androidResources\s*\{)/;
    const androidMatch = buildGradle.match(androidBlockEnd);

    if (androidMatch) {
      const splitsBlock = `
    splits {
        abi {
            enable true
            reset()
            include "arm64-v8a"
            universalApk false
        }
    }
$1`;
      buildGradle = buildGradle.replace(androidBlockEnd, splitsBlock);
    }

    configMod.modResults.contents = buildGradle;
    return configMod;
  });
};

/**
 * Main plugin function
 */
const withPalmIdConfig = (config, props = {}) => {
  config = withPalmIdMavenRepos(config);
  config = withAbiFilters(config);
  return config;
};

module.exports = createRunOncePlugin(
  withPalmIdConfig,
  'withPalmIdConfig',
  '1.0.0'
);
