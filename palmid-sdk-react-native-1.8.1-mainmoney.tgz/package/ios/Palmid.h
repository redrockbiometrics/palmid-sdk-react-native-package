#import <PalmidSpec/PalmidSpec.h>

@interface Palmid : NSObject <NativePalmidSpec>

@end
