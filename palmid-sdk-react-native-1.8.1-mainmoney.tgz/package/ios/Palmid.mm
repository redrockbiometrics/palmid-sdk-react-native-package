#import "Palmid.h"
#import <PalmIDNativeSDK/PalmIDNativeSDK.h>
#import <React/UIView+React.h>

@interface Palmid ()
@end

@implementation Palmid
RCT_EXPORT_MODULE()

- (std::shared_ptr<facebook::react::TurboModule>)getTurboModule:
    (const facebook::react::ObjCTurboModule::InitParams &)params
{
    return std::make_shared<facebook::react::NativePalmidSpecJSI>(params);
}

- (void)initialize:(JS::NativePalmid::InitializeOptions &)options resolve:(nonnull RCTPromiseResolveBlock)resolve reject:(nonnull RCTPromiseRejectBlock)reject {
    NSString *projectId = options.projectId();
    
    // Set default enrollment scans if not provided
    NSNumber *requiredEnrollmentScans = @2;
    if (options.requiredEnrollmentScans().has_value()) {
        double scans = options.requiredEnrollmentScans().value();
        if (scans > 0) {
            requiredEnrollmentScans = @(scans);
        }
    }
  
    NSString *palmServerEntrypoint = options.palmServerEntrypoint();
    NSString *appServerEntrypoint = options.appServerEntrypoint();
    
    dispatch_async(dispatch_get_main_queue(), ^{
        [[PalmIDNativeSDK sharedInstance] initializeWithPalmServerEntrypoint:palmServerEntrypoint
                                                           appServerEntrypoint:appServerEntrypoint
                                                                     projectId:projectId
                                                         requiredEnrollmentScans:requiredEnrollmentScans
                                                                      completion:^(BOOL success) {
            if (success) {
                resolve(@{@"success": @YES});
            } else {
                NSError *error = [NSError errorWithDomain:@"com.palmid" 
                                                     code:100001 
                                                 userInfo:@{NSLocalizedDescriptionKey: @"Failed to initialize PalmIDNativeSDK"}];
                reject(@"INIT_FAILED", @"Failed to initialize PalmIDNativeSDK", error);
            }
        }];
    });
}

- (void)enroll:(JS::NativePalmid::EnrollOptions &)options resolve:(RCTPromiseResolveBlock)resolve reject:(RCTPromiseRejectBlock)reject {
    NSString *appServerMessage = options.appServerMessage();
  
    dispatch_async(dispatch_get_main_queue(), ^{
        UIViewController *presentingController = RCTPresentedViewController();
        if (presentingController == nil) {
            NSError *error = [NSError errorWithDomain:@"com.palmid"
                                                 code:100002
                                             userInfo:@{NSLocalizedDescriptionKey: @"No application window available"}];
            reject(@"NO_WINDOW", @"No application window available", error);
            return;
        }
    
        [[PalmIDNativeSDK sharedInstance] enrollWithViewController:presentingController
                                                           loadController:nil
                                                            appServerMessage:appServerMessage
                                                                    result:^(PalmIDNativeResult * _Nonnull result) {
            NSDictionary *response = [self createResponseFromResult:result];
            resolve(response);
        }];
    });
}

- (void)verify:(JS::NativePalmid::VerifyOptions &)options resolve:(nonnull RCTPromiseResolveBlock)resolve reject:(nonnull RCTPromiseRejectBlock)reject {
    // Validate userId
    NSString *userId = options.userId();
    if (!userId || userId.length == 0) {
        NSError *error = [NSError errorWithDomain:@"com.palmid" 
                                             code:100003 
                                         userInfo:@{NSLocalizedDescriptionKey: @"User ID is required"}];
        reject(@"INVALID_USER_ID", @"User ID is required", error);
        return;
    }
  
    NSString *appServerMessage = options.appServerMessage();

    dispatch_async(dispatch_get_main_queue(), ^{
        UIViewController *presentingController = RCTPresentedViewController();
        if (presentingController == nil) {
            NSError *error = [NSError errorWithDomain:@"com.palmid"
                                                 code:100002
                                             userInfo:@{NSLocalizedDescriptionKey: @"No application window available"}];
            reject(@"NO_WINDOW", @"No application window available", error);
            return;
        }
            
        [[PalmIDNativeSDK sharedInstance] verifyWithUserId:userId
                                         viewController:presentingController
                                              loadController:nil
                                              appServerMessage:appServerMessage
                                                      result:^(PalmIDNativeResult * _Nonnull result) {
            NSDictionary *response = [self createResponseFromResult:result];
            resolve(response);
        }];
    });
}

- (void) identify:(JS::NativePalmid::EnrollOptions &)options resolve:(RCTPromiseResolveBlock)resolve reject:(RCTPromiseRejectBlock)reject {
  NSString *appServerMessage = options.appServerMessage();

  dispatch_async(dispatch_get_main_queue(), ^{
      UIViewController *presentingController = RCTPresentedViewController();
      if (presentingController == nil) {
          NSError *error = [NSError errorWithDomain:@"com.palmid"
                                               code:100002
                                           userInfo:@{NSLocalizedDescriptionKey: @"No application window available"}];
          reject(@"NO_WINDOW", @"No application window available", error);
          return;
      }
      
      [[PalmIDNativeSDK sharedInstance] identifyWithViewController:presentingController
                                                    loadController:nil
                                                  appServerMessage:appServerMessage
                                                            result:^(PalmIDNativeResult * _Nonnull result) {
          NSDictionary *response = [self createResponseFromResult:result];
          resolve(response);
      }];
  });
}

- (void)deleteUser:(JS::NativePalmid::PalmIdOperationOptions &)options resolve:(nonnull RCTPromiseResolveBlock)resolve reject:(nonnull RCTPromiseRejectBlock)reject {
    // Validate userId
    NSString *userId = options.userId();
    if (!userId || userId.length == 0) {
        NSError *error = [NSError errorWithDomain:@"com.palmid" 
                                             code:100003 
                                         userInfo:@{NSLocalizedDescriptionKey: @"User ID is required"}];
        reject(@"INVALID_USER_ID", @"User ID is required", error);
        return;
    }
    
    dispatch_async(dispatch_get_main_queue(), ^{
        [[PalmIDNativeSDK sharedInstance] deleteUser:userId
                                               result:^(PalmIDNativeResult * _Nonnull result) {
            NSDictionary *response = @{
                @"errorCode": @(result.errorCode ?: -1)
            };
            resolve(response);
        }];
    });
}

- (void)releaseEngine:(nonnull RCTPromiseResolveBlock)resolve reject:(nonnull RCTPromiseRejectBlock)reject {
    dispatch_async(dispatch_get_main_queue(), ^{
        [[PalmIDNativeSDK sharedInstance] releaseEngine];
        resolve(@{@"success": @YES});
    });
}

#pragma mark - Helper Methods

- (NSDictionary *)createResponseFromResult:(PalmIDNativeResult *)result {
    NSDictionary *resultData = @{};
    if (result.data != nil) {
        resultData = @{
            @"userId": result.data.userId ?: @"",
            @"score": @(result.data.score),
            @"sessionId": result.data.sessionId ?: @""
        };
    }
    
    return @{
        @"result": resultData,
        @"errorCode": @(result.errorCode ?: -1)
    };
}

@end
