module.exports = require('./plugins/withPalmIdConfig');
