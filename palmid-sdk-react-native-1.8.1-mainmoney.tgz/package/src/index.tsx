import Palmid, {
  type EnrollOptions,
  type InitializeOptions,
  type PalmIdOperationOptions,
  type PalmIdResult,
  PalmIDErrorCode,
} from './NativePalmid';

export { PalmIDErrorCode };

export type {
  EnrollOptions,
  InitializeOptions,
  PalmIdOperationOptions,
  PalmIdResult,
};

/**
 * Initialize the PalmID SDK
 */
export function initialize(
  options: InitializeOptions
): Promise<{ success: boolean }> {
  return Palmid.initialize(options);
}

/**
 * Verify user's palm print
 */
export function verify(options: PalmIdOperationOptions): Promise<PalmIdResult> {
  return Palmid.verify(options);
}

/**
 * Enroll a new user
 */
export function enroll(options?: EnrollOptions): Promise<PalmIdResult> {
  return Palmid.enroll(options ?? { appServerMessage: undefined });
}

/**
 * Identify a user
 */
export function identify(options?: EnrollOptions): Promise<PalmIdResult> {
  return Palmid.identify(options ?? { appServerMessage: undefined });
}

/**
 * Delete a user
 */
export function deleteUser(
  options: PalmIdOperationOptions
): Promise<PalmIdResult> {
  return Palmid.deleteUser(options);
}

/**
 * Release the engine
 */
export function releaseEngine(): Promise<void> {
  return Palmid.releaseEngine();
}
