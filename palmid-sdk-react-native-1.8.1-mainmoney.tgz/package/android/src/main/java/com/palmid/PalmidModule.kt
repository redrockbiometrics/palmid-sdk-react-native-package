package com.palmid

import android.os.Handler
import android.os.Looper
import com.facebook.react.bridge.Promise
import com.facebook.react.bridge.ReactApplicationContext
import com.facebook.react.bridge.Arguments
import com.facebook.react.bridge.ReadableMap
import com.facebook.react.bridge.WritableMap
import com.facebook.react.bridge.WritableArray
import com.facebook.react.module.annotations.ReactModule
import com.palmid.native_sdk.PalmIDNativeSDK
import com.palmid.native_sdk.model.PalmIDNativeResult

/**
 * React Native module for PalmID biometric authentication
 * Provides palm-based identification and enrollment functionality
 */
@ReactModule(name = PalmidModule.NAME)
class PalmidModule(reactContext: ReactApplicationContext) :
  NativePalmidSpec(reactContext) {

  companion object {
    const val NAME = "Palmid"

    // Error codes for better error handling
    private const val ERROR_CODE_SUCCESS = 0
    private const val ERROR_CODE_FAILED = -1

    private val mainHandler = Handler(Looper.getMainLooper())
  }

  /**
   * Returns the module name for React Native bridge
   */
  override fun getName(): String = NAME

  /**
   * Initializes the PalmID SDK with provided configuration options
   * @param options Configuration map containing server endpoints, project ID, and enrollment settings
   * @param promise Promise to resolve/reject the initialization result
   */
  override fun initialize(
    options: ReadableMap?,
    promise: Promise?
  ) = safeExecute(promise) {
    requireNotNull(options) { "Initialization options cannot be null" }

    val palmServerEntrypoint = options.getString("palmServerEntrypoint")
    val appServerEntrypoint = options.getString("appServerEntrypoint")
    val projectId = options.getString("projectId") ?: ""
    val requiredEnrollmentScans = options.getInt("requiredEnrollmentScans")

    mainHandler.post {
      PalmIDNativeSDK.getInstance()
        .initialize(
          reactApplicationContext,
          palmServerEntrypoint,
          appServerEntrypoint,
          projectId,
          requiredEnrollmentScans
        ) { success ->
          when {
            success -> promise?.resolve(true)
            else -> promise?.reject("INIT_FAILED", "Failed to initialize PalmIDNativeSDK")
          }
        }
    }
  }

  /**
   * Verifies a user's palm biometric against stored data
   * @param options Map containing userId for verification
   * @param promise Promise to resolve/reject the verification result
   */
  override fun verify(options: ReadableMap?, promise: Promise?) = safeExecute(promise) {
    val activity = requireNotNull(reactApplicationContext.currentActivity) {
      "Current activity is null - ensure app is in foreground"
    }

    val appServerMessage = options?.getString("appServerMessage")

    val userId = options?.getString("userId")?.takeIf { it.isNotEmpty() }
      ?: throw IllegalArgumentException("userId is required and cannot be empty")

    mainHandler.post {
      PalmIDNativeSDK.getInstance()
        .verifyWithUserId(activity, userId, null, appServerMessage) { result ->
          val responseMap = createResponseMap(result)
          promise?.resolve(responseMap)
        }
    }
  }

  /**
   * Enrolls a new user's palm biometric data
   * @param promise Promise to resolve/reject the enrollment result
   */
  override fun enroll(options: ReadableMap?, promise: Promise?) = safeExecute(promise) {
    val activity = requireNotNull(reactApplicationContext.currentActivity) {
      "Current activity is null - ensure app is in foreground"
    }

    val appServerMessage = options?.getString("appServerMessage")

    mainHandler.post {
      PalmIDNativeSDK.getInstance()
        .enroll(activity, null, appServerMessage) { result ->
          val responseMap = createResponseMap(result)
          promise?.resolve(responseMap)
        }
    }
  }

  /**
   * Identify a user
   * @param options Map containing appServerMessage for identification
   * @param promise Promise to resolve/reject the identification result
   */
  override fun identify(options: ReadableMap?, promise: Promise?) {
    val activity = requireNotNull(reactApplicationContext.currentActivity) {
      "Current activity is null - ensure app is in foreground"
    }

    val appServerMessage = options?.getString("appServerMessage")

    mainHandler.post {
      PalmIDNativeSDK.getInstance()
        .identify(activity, null, appServerMessage) { result ->
          val responseMap = createResponseMap(result)
          promise?.resolve(responseMap)
        }
    }
  }

  /**
   * Deletes a user's palm biometric data from the system
   * @param options Map containing userId to delete
   * @param promise Promise to resolve/reject the deletion result
   */
  override fun deleteUser(
    options: ReadableMap?,
    promise: Promise?
  ) = safeExecute(promise) {
    val userId = options?.getString("userId")?.takeIf { it.isNotEmpty() }
      ?: throw IllegalArgumentException("userId is required and cannot be empty")

    mainHandler.post {
      PalmIDNativeSDK.getInstance().deleteUser(userId) { result ->
        val responseMap = Arguments.createMap().apply {
          putInt("errorCode", result?.errorCode ?: ERROR_CODE_FAILED)
        }
        promise?.resolve(responseMap)
      }
    }
  }

  /**
   * Releases the PalmID SDK engine and cleans up resources
   * @param promise Promise to resolve/reject the release result
   */
  override fun releaseEngine(promise: Promise?) = safeExecute(promise) {
    mainHandler.post {
      PalmIDNativeSDK.getInstance().releaseEngine()
      promise?.resolve(true)
    }
  }

  /**
   * Helper function to safely execute operations with error handling
   * @param promise Promise to handle errors
   * @param block Operation to execute safely
   */
  private inline fun safeExecute(promise: Promise?, block: () -> Unit) {
    try {
      block()
    } catch (e: Exception) {
      promise?.reject(e)
    }
  }

  /**
   * Creates a standardized response map from SDK result
   * @param result SDK operation result
   * @return WritableMap with standardized response format
   */
  private fun createResponseMap(result: PalmIDNativeResult?): WritableMap {
    val responseMap = Arguments.createMap()

    result?.let { r ->
      // Set error code
      responseMap.putInt("errorCode", r.errorCode)

      // Process result data if available
      r.data?.let { data ->
        val dataMap = Arguments.createMap().apply {
          putString("userId", data.userId)
          putDouble("score", data.score)

          // Handle optional sessionId
          data.sessionId?.let { sessionId ->
            putString("sessionId", sessionId)
          }

          // Handle optional palmModels list
          data.palmModels?.let { palmModels ->
            if (palmModels.isNotEmpty()) {
              val palmModelsArray = Arguments.createArray()
              palmModels.forEach { model ->
                palmModelsArray.pushString(model)
              }
              putArray("palmModels", palmModelsArray)
            }
          }

          // Handle optional meta map
          data.meta?.let { meta ->
            if (meta.isNotEmpty()) {
              val metaMap = Arguments.createMap()
              meta.forEach { (key, value) ->
                when (value) {
                  is String -> metaMap.putString(key, value)
                  is Number -> metaMap.putDouble(key, value.toDouble())
                  is Boolean -> metaMap.putBoolean(key, value)
                  is org.json.JSONObject -> metaMap.putString(key, value.toString())
                  is org.json.JSONArray -> metaMap.putString(key, value.toString())
                  else -> metaMap.putString(key, value.toString())
                }
              }
              putMap("meta", metaMap)
            }
          }
        }
        responseMap.putMap("result", dataMap)
      }
    } ?: run {
      // If result is null, return error
      responseMap.putInt("errorCode", ERROR_CODE_FAILED)
    }

    return responseMap
  }
}
