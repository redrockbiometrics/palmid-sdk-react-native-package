import { type TurboModule } from 'react-native';
/**
 * PalmIDErrorCode
 */
export declare enum PalmIDErrorCode {
    Success = 100000,
    UserCancelled = -1,
    Authentication = 100001,
    UserNotFound = 100002,
    NoMatchUser = 100003,
    UserAlreadyExists = 100004,
    Enroll = 100005,
    Identify = 100006,
    Verify = 100007,
    DeleteUser = 100008,
    Other = 999999
}
export interface InitializeOptions {
    /**
     * (Optional) PalmID server entry point URL for SaaS or self-hosted
     */
    palmServerEntrypoint?: string;
    /**
     * (Optional) Your session ID server entry point URL
     */
    appServerEntrypoint?: string;
    /**
     * Required, project ID
     */
    projectId: string;
    /**
     * Optional, number of scans required for enrollment, default is 1
     */
    requiredEnrollmentScans?: number;
}
export interface PalmIdOperationOptions {
    /**
     * Unique user ID
     */
    userId: string;
}
export interface EnrollOptions {
    /**
     * (Optional) App server message
     */
    appServerMessage?: string;
}
export interface VerifyOptions extends PalmIdOperationOptions {
    /**
     * (Optional) App server message
     */
    appServerMessage?: string;
}
export interface PalmIdResult {
    errorCode: PalmIDErrorCode;
    result: {
        userId: string;
        /**
         * (Optional) Session ID, only available when appServerEntrypoint is provided
         */
        sessionId?: string;
        score?: number;
    };
}
export interface Spec extends TurboModule {
    /**
     * Initialize the PalmID SDK
     */
    initialize(options: InitializeOptions): Promise<{
        success: boolean;
    }>;
    /**
     * Verify user's palm print
     */
    verify(options: VerifyOptions): Promise<any>;
    /**
     * Enroll a new user
     */
    enroll(options?: EnrollOptions | undefined): Promise<any>;
    /**
     * Identify a user
     */
    identify(options?: EnrollOptions | undefined): Promise<any>;
    /**
     * Delete a user
     */
    deleteUser(options: PalmIdOperationOptions): Promise<any>;
    /**
     * Release the engine
     */
    releaseEngine(): Promise<void>;
}
declare const _default: Spec;
export default _default;
//# sourceMappingURL=NativePalmid.d.ts.map