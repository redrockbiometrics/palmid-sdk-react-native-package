import { type EnrollOptions, type InitializeOptions, type PalmIdOperationOptions, type PalmIdResult, PalmIDErrorCode } from './NativePalmid';
export { PalmIDErrorCode };
export type { EnrollOptions, InitializeOptions, PalmIdOperationOptions, PalmIdResult, };
/**
 * Initialize the PalmID SDK
 */
export declare function initialize(options: InitializeOptions): Promise<{
    success: boolean;
}>;
/**
 * Verify user's palm print
 */
export declare function verify(options: PalmIdOperationOptions): Promise<PalmIdResult>;
/**
 * Enroll a new user
 */
export declare function enroll(options?: EnrollOptions): Promise<PalmIdResult>;
/**
 * Identify a user
 */
export declare function identify(options?: EnrollOptions): Promise<PalmIdResult>;
/**
 * Delete a user
 */
export declare function deleteUser(options: PalmIdOperationOptions): Promise<PalmIdResult>;
/**
 * Release the engine
 */
export declare function releaseEngine(): Promise<void>;
//# sourceMappingURL=index.d.ts.map