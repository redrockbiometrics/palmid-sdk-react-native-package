# palmid-sdk-react-native

Palmid sdk for react native

## Installation

**Important:** This package is **not** published to npm. Install it directly from the release tarball:

Using **pnpm**:

```bash
pnpm add "https://rrbpalm-dist.vecrel.com/sdk/releases/palmid-sdk-react-native-1.8.1-mainmoney.tgz"
```

Using **npm**:

```bash
npm install "https://rrbpalm-dist.vecrel.com/sdk/releases/palmid-sdk-react-native-1.8.1-mainmoney.tgz"
```

Using **Yarn**:

```bash
yarn add "https://rrbpalm-dist.vecrel.com/sdk/releases/palmid-sdk-react-native-1.8.1-mainmoney.tgz"
```


### Local Installation

1. In your app project root, add `"palmid-sdk-react-native": "file:<path-to-your-react-native-palmid-repo>"` to your `package.json`.
2. In the library root, run `yarn install`.
3. Then run `yarn prepare` to build the library.
4. Then, in your app root directory, run `yarn install` or `npm install` to install this library.
5. In your app project root, edit `metro.config.js`:

```javascript
const { getDefaultConfig } = require('expo/metro-config'); // or @react-native/metro-config
const path = require('path');

const config = getDefaultConfig(__dirname);

const localPalmidPath = path.resolve('<path-to-your-react-native-palmid-repo>');

config.watchFolders = [
  path.resolve(__dirname),
  localPalmidPath,
];

config.resolver = config.resolver || {};
config.resolver.extraNodeModules = {
  ...config.resolver.extraNodeModules,
  'palmid-sdk-react-native': localPalmidPath,
};

module.exports = config;
```

6. Optionally, in your app's `ios` directory, run `pod install` to install CocoaPods dependencies.

### For Expo users

1. In your app's `app.json`, add the plugin:

```json
"plugins": [
  ...,
  "palmid-sdk-react-native"
],
```
2. Re-generate native projects:

```bash
npx expo prebuild --clean
```

## iOS

iOS requires the following usage description be added and filled out for your app in `Info.plist`:

- `NSCameraUsageDescription` (`Privacy - Camera Usage Description`)

Read about [Configuring `Info.plist`](https://capacitorjs.com/docs/ios/configuration#configuring-infoplist) in the [iOS Guide](https://capacitorjs.com/docs/ios) for more information on setting iOS permissions in Xcode

## Android

If that entry is not added, the devices that don't support the Photo Picker, the Photo Picker component fallbacks to `Intent.ACTION_OPEN_DOCUMENT`.

The Camera plugin requires `CAMERA` permission, in that case the following permissions should be added to your `AndroidManifest.xml`:

```xml
<uses-permission android:name="android.permission.CAMERA"/>
```
Read about [Setting Permissions](https://capacitorjs.com/docs/android/configuration#setting-permissions) in the [Android Guide](https://capacitorjs.com/docs/android) for more information on setting Android permissions.

### Add PalmID SDK repository

```gradle
repositories {
    flatDir{
        dirs '../capacitor-cordova-android-plugins/src/main/libs', 'libs'
    }
    maven {
        url = uri("https://storage.googleapis.com/download.flutter.io")
    }
    maven {
        url = uri("https://raw.githubusercontent.com/redrockbiometrics/palmid-sdk-android-repo/master")
    }
}
```

## Usage

```typescript
import { initialize, enroll, verify, deleteUser, releaseEngine } from 'palmid-sdk-react-native';
```

## API

<docgen-index>

* [`initialize(...)`](#initialize)
* [`verify(...)`](#verify)
* [`identify()`](#identify)
* [`enroll()`](#enroll)
* [`deleteUser(...)`](#deleteuser)
* [`releaseEngine()`](#releaseengine)
* [Interfaces](#interfaces)
* [Enums](#enums)

</docgen-index>

<docgen-api>
<!--Update the source file JSDoc comments and rerun docgen to update the docs below-->

### initialize(...)

```typescript
initialize(options: InitializeOptions) => Promise<{ success: boolean; }>
```

Initialize the PalmID SDK

| Param         | Type                                                            |
| ------------- | --------------------------------------------------------------- |
| **`options`** | <code><a href="#initializeoptions">InitializeOptions</a></code> |

**Returns:** <code>Promise&lt;{ success: boolean; }&gt;</code>

--------------------


### verify(...)

```typescript
verify(options: VerifyOptions) => Promise<PalmIdResult>
```

Verify user's palm print

| Param         | Type                                                                      |
| ------------- | ------------------------------------------------------------------------- |
| **`options`** | <code><a href="#verifyoptions">VerifyOptions</a></code> |

**Returns:** <code>Promise&lt;<a href="#palmidresult">PalmIdResult</a>&gt;</code>

--------------------

### identify()

```typescript
identify(options: EnrollOptions) => Promise<PalmIdResult>
```

Identify a user

| Param         | Type                                                                      |
| ------------- | ------------------------------------------------------------------------- |
| **`options`** | <code><a href="#enrolloptions">EnrollOptions</a></code> |

**Returns:** <code>Promise&lt;<a href="#palmidresult">PalmIdResult</a>&gt;</code>

--------------------


### enroll()

```typescript
enroll(options: EnrollOptions) => Promise<PalmIdResult>
```

Enroll a new user

| Param         | Type                                                                      |
| ------------- | ------------------------------------------------------------------------- |
| **`options`** | <code><a href="#enrolloptions">EnrollOptions</a></code> |

**Returns:** <code>Promise&lt;<a href="#palmidresult">PalmIdResult</a>&gt;</code>

--------------------


### deleteUser(...)

```typescript
deleteUser(options: PalmIdOperationOptions) => Promise<PalmIdResult>
```

Delete a user

| Param         | Type                                                                      |
| ------------- | ------------------------------------------------------------------------- |
| **`options`** | <code><a href="#palmidoperationoptions">PalmIdOperationOptions</a></code> |

**Returns:** <code>Promise&lt;<a href="#palmidresult">PalmIdResult</a>&gt;</code>

--------------------


### releaseEngine()

```typescript
releaseEngine() => Promise<void>
```

Release the engine

--------------------


### Interfaces


#### InitializeOptions

| Prop                          | Type                | Description                                                      |
| ----------------------------- | ------------------- | ---------------------------------------------------------------- |
| **`palmServerEntrypoint`**    | <code>string</code> | (Optional) PalmID server entry point URL for SaaS or self-hosted |
| **`appServerEntrypoint`**     | <code>string</code> | (Optional) Your session ID server entry point URL                |
| **`projectId`**               | <code>string</code> | Required, project ID                                             |
| **`requiredEnrollmentScans`** | <code>number</code> | Optional, number of scans required for enrollment, default is 1  |


#### PalmIdResult

| Prop            | Type                                                                 |
| --------------- | -------------------------------------------------------------------- |
| **`errorCode`** | <code><a href="#palmiderrorcode">PalmIDErrorCode</a></code>          |
| **`result`**    | <code>{ userId: string; sessionId?: string; score?: number; }</code> |


#### PalmIdOperationOptions

| Prop         | Type                | Description    |
| ------------ | ------------------- | -------------- |
| **`userId`** | <code>string</code> | Unique user ID |

#### EnrollOptions

| Prop         | Type                | Description    |
| ------------ | ------------------- | -------------- |
| **`appServerMessage`** | <code>string</code> | (Optional) App server message |

#### VerifyOptions

| Prop         | Type                | Description    |
| ------------ | ------------------- | -------------- |
| **`userId`** | <code>string</code> | Required, unique user ID |
| **`appServerMessage`** | <code>string</code> | (Optional) App server message |

### Enums


#### PalmIDErrorCode

| Members                 | Value               |
| ----------------------- | ------------------- |
| **`Success`**           | <code>100000</code> |
| **`UserCancelled`**     | <code>-1</code>     |
| **`Authentication`**    | <code>100001</code> |
| **`UserNotFound`**      | <code>100002</code> |
| **`NoMatchUser`**       | <code>100003</code> |
| **`UserAlreadyExists`** | <code>100004</code> |
| **`Enroll`**            | <code>100005</code> |
| **`Identify`**          | <code>100006</code> |
| **`Verify`**            | <code>100007</code> |
| **`DeleteUser`**        | <code>100008</code> |
| **`Other`**             | <code>999999</code> |

</docgen-api>


## Contributing

- [Development workflow](CONTRIBUTING.md#development-workflow)
- [Sending a pull request](CONTRIBUTING.md#sending-a-pull-request)
- [Code of conduct](CODE_OF_CONDUCT.md)

## License

MIT

---

Made with [create-react-native-library](https://github.com/callstack/react-native-builder-bob)